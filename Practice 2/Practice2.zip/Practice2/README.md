## Autor: Ortega Garcia Alejandra - 420002495
## Autor: Pedro Mendez Jose Manuel - 315073120

TM es la clase que nos permite simular el algoritmo universal de una MT, lo correspondiente al ejercicio 1.
N.json es el archivo JSON que representa la MT que acepta el lenguaje del ejercicio 2.

Comando para ejecutar el codigo; python2 TM.py
El archivo JSON que representa la MT que desea leer debe de estar en la carpeta donde se encuentra el archivo TM.py
