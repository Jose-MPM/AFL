# Implementación de la práctica 02 de Automatas

## Autor: Ortega Garcia Alejandra
## Autor: Pedro Mendez Jose Manuel

Para ejecutar el proyecto se usan los siguientes comandos:

1. ant build

2. ant jar

3. ant run

Se recomienda que al finalizar la ejecución del programa se use el comando siguiente:

4. ant clean
